---
name: Sartorial Heritage & Haute Couture
colors:
  surface: '#faf9fd'
  surface-dim: '#dbd9de'
  surface-bright: '#faf9fd'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f4f3f7'
  surface-container: '#efedf2'
  surface-container-high: '#e9e7ec'
  surface-container-highest: '#e3e2e6'
  on-surface: '#1a1b1f'
  on-surface-variant: '#44464f'
  inverse-surface: '#2f3034'
  inverse-on-surface: '#f1f0f4'
  outline: '#757780'
  outline-variant: '#c5c6d0'
  surface-tint: '#4a5d8f'
  primary: '#475a8d'
  on-primary: '#ffffff'
  primary-container: '#6073a7'
  on-primary-container: '#fefcff'
  inverse-primary: '#b2c5fe'
  secondary: '#585e74'
  on-secondary: '#ffffff'
  secondary-container: '#dce1fc'
  on-secondary-container: '#5e647a'
  tertiary: '#735b13'
  on-tertiary: '#ffffff'
  tertiary-container: '#c6a859'
  on-tertiary-container: '#503d00'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae2ff'
  primary-fixed-dim: '#b2c5fe'
  on-primary-fixed: '#001847'
  on-primary-fixed-variant: '#324576'
  secondary-fixed: '#dce1fc'
  secondary-fixed-dim: '#c0c5df'
  on-secondary-fixed: '#151b2e'
  on-secondary-fixed-variant: '#40465b'
  tertiary-fixed: '#ffdf91'
  tertiary-fixed-dim: '#e3c371'
  on-tertiary-fixed: '#241a00'
  on-tertiary-fixed-variant: '#594400'
  background: '#faf9fd'
  on-background: '#1a1b1f'
  surface-variant: '#e3e2e6'
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
  space-2xl: 4rem
  space-3xl: 6rem
---

## Brand & Style

### Brand Personality & Voice
This design system embodies the quiet confidence, exacting precision, and storied tradition of bespoke sartorial craftsmanship. Conceived for a premier tailoring house, the interface communicates heritage through restraint, deliberate composition, and tactile refinement. The tone is discreetly authoritative, hospitable, and uncompromisingly sophisticated—mirroring the private atelier experience where every measurement, lapel stitch, and cloth selection is executed with deliberate purpose.

### Target Audience & Emotional Intent
The target clientele comprises discerning gentlemen and ladies, wedding parties, diplomats, and connoisseurs seeking custom tailoring, fine woolens, and personalized fitting services. The UI evokes feelings of calm distinction, exclusivity, and dependable mastery. Users must feel transported into a serene fitting parlor rather than a commercial checkout flow.

### Design Movement: Tailored Editorial Minimalism
The interface synthesizes classical Savile Row-inspired editorial typography with contemporary architectural minimalism. It avoids excessive decorative flourishes, instead employing:
- Ample, breathable stone gray and neutral negative space reflecting premium paper stationery.
- Tailored hairline boundaries reminiscent of bespoke pattern tracing and basted stitching.
- Muted gold accents used sparingly as seals of authenticity and focus cues.
- High-contrast photographic treatments showcasing textile weaves, horn buttons, and silhouette drape.

## Colors

### Palette Architecture
The palette is rooted in the timeless interplay between muted slate-blue wool and refined stone:

- **Primary (`#6376AA` — Muted Slate Blue):** The structural anchor. Employed for authoritative typography, primary button fills, prominent header bars, and grounding architectural elements.
- **Secondary (`#70768D` — Refined Slate Gray):** The artisanal signature. Reserved for subtle highlights, badges of craftsmanship, active status states, borders of featured tiers, and key interactive accents.
- **Tertiary (`#C6A859` — Muted Gold):** Used for elevated containers, warm contextual highlights, and high-contrast accent backdrops.
- **Neutral Canvas (`#77777B` — Architectural Gray):** The foundation tint, establishing a balanced, understated modern architectural atmosphere.
- **Pure Surface (`#FFFFFF` — Crisp Linen White):** Used for elevated cards, modal sheets, and pristine swatch cards to maintain pure optical contrast against textiles.

### Application Rules
Maintain strict restraint with the gold and secondary accents: they should never exceed optical balance on any view. Surfaces remain clean and sophisticated, anchored by slate-blue typography.

## Typography

### Structural Pairing
The typography pairs the high-contrast elegance of **Playfair Display** with the clear legibility of **Noto Sans**. 

- **Playfair Display** commands all high-order brand elements, collection headings, atelier titles, and bespoke tier labels.
- **Noto Sans** provides seamless rendering and neutral readability for fabric specifications, sizing charts, fitting steps, and consultation guides.

### Letter-Spacing & Casing Principles
Section labels, categorization kickers, and step numbers must leverage `label-uppercase` styled in uppercase text with wide tracking (`0.14em`). Editorial headlines must never be set in all caps, preserving the graceful ascenders and descenders of Playfair Display.

## Layout & Spacing

### Layout Philosophy
A disciplined 12-column grid provides the structural framework on desktop screens, collapsing to an 8-column layout on tablet devices and a 4-column layout on mobile viewports. Canvas margins are generously proportioned to ensure content feels curated like an exhibition catalog.

### Rhythm & Proportions
Vertical rhythm follows an 8px modular baseline. Section transitions employ large spatial breathing rooms (`space-2xl` and `space-3xl`) to establish grandeur and prevent visual clutter. Within component interiors, compact spacing (`space-sm` to `space-md`) ensures crisp informational density.

### Breakpoints & Responsive Behavior
- **Mobile (< 768px):** Outer margins contract to `1.25rem` (`margin-mobile`), gutter settles at `1rem`.
- **Tablet (768px - 1024px):** Margins set to `2rem`, gutters at `1.25rem`.
- **Desktop (> 1024px):** Fixed content container capped at `1280px` maximum width, centered with `3rem` margins to preserve optimal line lengths.

## Elevation & Depth

### Tactile Restraint
In alignment with bespoke tailoring values, depth is established through physical paper-like layering, hairline seams, and soft ambient light, completely avoiding artificial heavy drop shadows or bright glossy effects.

### Layering Hierarchy
1. **Atelier Canvas (Ground):** Soft neutral base.
2. **Elevated Garment Tier (Level 1):** `#FFFFFF` surfaces featuring razor-sharp `1px` borders.
3. **Floating Interaction Sheets & Fitting Drawers (Level 2):** Layered containers utilize ultra-subtle, ambient slate-tinted illumination.
4. **Focused Fabric & Modal Inspection (Level 3):** Deep overlay backdrops paired with a gentle backdrop blur, elevating crisp white presentation sheets.

## Shapes

### Tailored Softness (`roundedness: 1`)
Geometry is disciplined, architectural, and tailored. Elements feature a refined, subtle softening:
- Base elements (buttons, inputs, swatch tiles, tag pills) use `0.25rem` (4px) corner radii.
- Medium structural components use `0.5rem` (8px).
- Modals and luxury promotional banners use `0.75rem` (12px).

Pill-shaped buttons and aggressive rounded curves are strictly avoided; lines remain composed and deliberate.

## Components

### Buttons
- **Primary Atelier Button:** Solid `#6376AA` background, pure white text, `0.25rem` radius, `label-standard` typography.
- **Secondary Tailor Button:** Transparent background, `1px solid #6376AA` border, `#6376AA` text.
- **Gold Accent (Consultation Booking):** Solid `#C6A859` background with deep text for direct appointment booking and fitting reservations.

### Cards & Collection Panes
- **Suit Collection Card:** Crisp `#FFFFFF` surface bounded by a subtle `1px` hairline border. Includes category kicker in `label-uppercase` gold text, suit title in `headline-sm`, and fabrication details in `body-sm`.
- **Fabric Swatch Card:** Square presentation card containing high-definition textile preview, active state marked by a `2px solid #70768D` or `#C6A859` perimeter frame.

### Form Inputs & Consultation Booking
- **Input Fields:** Uncluttered `#FFFFFF` surfaces with a fine `1px` border. Focused state transitions the border to `#6376AA` with no glow ring.
- **Radio Buttons & Checkboxes:** Custom square-angled controls with subtle 2px rounded corners.